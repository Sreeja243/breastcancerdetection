from flask import Flask,render_template,request
from numpy import round
from tensorflow import keras
app=Flask(__name__)
@app.route('/')
def index():
    return render_template('base.html')
@app.route('/myann')
def tem():
  return render_template('index.html')
@app.route('/model')
def model():
    model=keras.models.load_model("C:\\Users\\sreej\\Untitled Folder 2\\mymodel")
    l=[[0.6431444933503716,
  0.27257355427798435,
  0.6157832907193699,
  0.5015906680805938,0.08474,0.07864,0.0869,
  0.07017,0.1812,0.05667,
  0.15643671917436172,
  0.08258928571428571,0.12444046553267685,
  0.12565978953974424,
  0.005225,
  0.01308,
  0.0186,
  0.0134,
  0.01389,
  0.003532,
  0.606901458555674,
  0.3035714285714286,
  0.5398177200059764,
  0.43521431380259534,
  0.1238,0.15456335923780695,
  0.1929712460063898, 0.186,
  0.275, 0.08902]]
    res=model.predict(l)[0]
    return str(res)
@app.route('/', methods=['POST'])
def my_form_post():
      l=[]
      l.append(float(request.form["radius_mean"]))
      l.append(float(request.form["texture_mean"]))
      l.append(float(request.form["perimeter_mean"]))
      l.append(float(request.form["area_mean"]))
      l.append(float(request.form["smoothness_mean"]))
      l.append(float(request.form["compactness_mean"]))
      l.append(float(request.form["concavity_mean"]))
      l.append(float(request.form["concavepoints_mean"]))
      l.append(float(request.form["symmetry_mean"]))
      l.append(float(request.form["fractal_dimension_mean" ]))
      l.append(float(request.form["radius_se" ]))
      l.append(float(request.form["texture_se" ]))
      l.append(float(request.form["perimeter_se" ]))
      l.append(float(request.form["area_se" ]))
      l.append(float(request.form["smoothness_se" ]))
      l.append(float(request.form["compactness_se" ]))
      l.append(float(request.form["concavity_se" ]))
      l.append(float(request.form["concavepoints_se" ]))
      l.append(float(request.form["symmetry_se" ]))
      l.append(float(request.form["fractal_dimension_se" ]))
      l.append(float(request.form["radius_worst" ]))
      l.append(float(request.form["texture_worst" ]))
      l.append(float(request.form["perimeter_worst" ]))
      l.append(float(request.form["area_worst" ]))
      l.append(float(request.form["smoothness_worst" ]))
      l.append(float(request.form["compactness_worst" ]))
      l.append(float(request.form["concavity_worst" ]))
      l.append(float(request.form["concavepoints_worst" ]))
      l.append(float(request.form["symmetry_worst" ]))
      l.append(float(request.form["fractal_dimension_worst" ]))
      x=[l]
      model=keras.models.load_model("C:\\Users\\sreej\\Untitled Folder 2\\mymodel")
      res=model.predict(x)[0]
      if(round(res)==1):
        return render_template('index_base.html',flag=1)
      else:
        return render_template('index_base.html',flag=0)
if __name__=='__main__':
    app.run(port=5333,debug=True)